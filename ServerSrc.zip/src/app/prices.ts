export interface Prices {
    id: string;
    standard: number;
    deluxe: number;
    superDeluxe: number;
    foodPackage: number;
    electricityBillPerUnit: number;
    securityDeposit: number;
}
